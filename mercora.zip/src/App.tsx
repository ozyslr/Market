import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Navbar } from './components/layout/Navbar';
import { CartPage } from './pages/Cart';
import { Home } from './pages/Home';
import { ProductDetail } from './pages/ProductDetail';
import { SellerDashboard } from './pages/SellerDashboard';
import { SellerInventoryPage } from './pages/SellerInventory';
import { SellerOrdersPage } from './pages/SellerOrders';
import { SellerStorePage } from './pages/SellerStore';
import { SearchResultsPage } from './pages/SearchResults';
import { UserProfilePage } from './pages/UserProfile';
import { ShoppingAssistant } from './components/ai/ShoppingAssistant';
import { Footer } from './components/layout/Footer';
import { LanguageProvider } from './context/LanguageContext';

export default function App() {
  return (
    <LanguageProvider>
      <Router>
        <div className="relative min-h-screen">
          <Navbar />
          
          <main>
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/product/:slug" element={<ProductDetail />} />
              <Route path="/cart" element={<CartPage />} />
              <Route path="/seller/dashboard" element={<SellerDashboard />} />
              <Route path="/seller/inventory" element={<SellerInventoryPage />} />
              <Route path="/seller/orders" element={<SellerOrdersPage />} />
              <Route path="/seller/:id" element={<SellerStorePage />} />
              <Route path="/search" element={<SearchResultsPage />} />
              <Route path="/profile" element={<UserProfilePage />} />
              <Route path="*" element={<Home />} />
            </Routes>
          </main>

          <Footer />
          <ShoppingAssistant />
        </div>
      </Router>
    </LanguageProvider>
  );
}
